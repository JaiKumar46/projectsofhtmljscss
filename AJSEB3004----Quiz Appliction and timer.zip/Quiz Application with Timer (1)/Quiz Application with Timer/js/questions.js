// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "What does HTML stand for?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
    {
    numb: 2,
    question: "What does CSS stand for?",
    answer: "Cascading Style Sheet",
    options: [
      "Common Style Sheet",
      "Colorful Style Sheet",
      "Computer Style Sheet",
      "Cascading Style Sheet"
    ]
  },
    {
    numb: 3,
    question: " Javascript is an _______ language?",
    answer: "Object Oriented",
    options: ["Object Oriented", "Object Based", "Procedural", "none of these"],
  },
    {
    numb: 4,
    question: "Upon encountering empty statements, what does the Javascript Interpreter do?",
    answer: "ignores the statements",
    options: [
      "throws an error",
      "ignores the statements",
      "gives warning",
      "executes the statements",
    ],
  },
    {
    numb: 5,
    question: "Suppose we want to arrange three DIVs so that DIV 3 is placed above DIV1. Now, which CSS property are we going to use to control the stack order?",
    answer: "z-index",
    options: ["d-index", "s-index", "x-index", "z-index"],
  },

  
];